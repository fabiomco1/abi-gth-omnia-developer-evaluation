﻿namespace Ambev.DeveloperEvaluation.Common.Security
{
	public interface ISaleProduct
	{
		public string Id { get; }
		public string ProductId { get; }
	}
}