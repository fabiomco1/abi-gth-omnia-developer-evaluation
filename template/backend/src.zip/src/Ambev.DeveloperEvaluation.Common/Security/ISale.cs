﻿namespace Ambev.DeveloperEvaluation.Common.Security
{
	public interface ISale
	{
		public string Id { get; }
	}
}