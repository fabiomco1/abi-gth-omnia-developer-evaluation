namespace Ambev.DeveloperEvaluation.Domain.Enums;

public enum UserStatus
{
    Unknown = 0,
    Active,
    Inactive,
    Suspended
}
