﻿namespace Ambev.DeveloperEvaluation.WebApi.Features.SalesProducts.CreateSaleProduct
{
	public class CreateSaleProductRequestValidator
	{
	}
}
