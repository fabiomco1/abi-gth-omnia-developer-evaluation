﻿namespace Ambev.DeveloperEvaluation.WebApi.Features.Product.CreateProduct
{
	public class CreateProductRequestValidator
	{
	}
}
