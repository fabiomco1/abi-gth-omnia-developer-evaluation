﻿namespace Ambev.DeveloperEvaluation.Application.Products.CreateProduct
{
	public class CreateProductResponse
	{
		public string ProductName { get; set; }
		public decimal Price { get; set; }

	}
}