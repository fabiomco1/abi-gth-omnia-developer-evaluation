﻿namespace Ambev.DeveloperEvaluation.WebApi.Mappings
{
	public class CreateSaleProductRequest
	{
	}
}
