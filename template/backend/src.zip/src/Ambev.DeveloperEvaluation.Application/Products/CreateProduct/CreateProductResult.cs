﻿namespace Ambev.DeveloperEvaluation.Application.Products.CreateProduct;

public class CreateProductResult
{
	public string Id { get; set; }
	public string ProductName { get; set; } = string.Empty;
}