﻿
namespace Ambev.DeveloperEvaluation.Application.SalesProducts.CreateSaleProducts
{
	internal class CreateSaleProductHandler
	{
	}
}
